namespace HospitalSurgeAgent.API.Dtos;

/// <summary>Readable campaign status for Swagger / testing.</summary>
public sealed class CampaignStatusResponse
{
    public string CampaignId { get; set; } = "";
    public string StaffGroup { get; set; } = "";
    public string Situation { get; set; } = "";
    public int SurgeRiskLevel { get; set; }

    public int RequiredStaff { get; set; }

    /// <summary>Number of staff confirmed by the unit manager.</summary>
    public int ConfirmedStaff { get; set; }

    /// <summary>Number of staff who accepted but are awaiting manager confirmation.</summary>
    public int PendingAcceptedStaff { get; set; }

    /// <summary>For backward compatibility with older UI fields.</summary>
    public int AcceptedStaff { get; set; }

    public int RemainingNeeded { get; set; }
    public bool IsFilled { get; set; }

    public int? FinalPremiumPercent { get; set; }
    public DateTime? FinalizedUtc { get; set; }

    /// <summary>All sessions that have been created so far.</summary>
    public List<SessionStatusItem> Sessions { get; set; } = new();
}

/// <summary>Per staff session status.</summary>
public sealed class SessionStatusItem
{
    public string LinkCode { get; set; } = "";
    public string Recipient { get; set; } = "";
    public string Status { get; set; } = "";
    public int DeclineCount { get; set; }
    public int? AcceptedPremiumPercent { get; set; }
    public DateTime CreatedUtc { get; set; }
    public DateTime LastActivityUtc { get; set; }
}
