namespace HospitalSurgeAgent.API.Dtos;

/// <summary>Message posted by staff in the chat.</summary>
public sealed class ReplyRequest
{
    /// <summary>Staff message (e.g. "decline" or "accept").</summary>
    public string Message { get; set; } = "";
}
