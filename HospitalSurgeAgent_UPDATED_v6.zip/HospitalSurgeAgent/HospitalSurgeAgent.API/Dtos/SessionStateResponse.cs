namespace HospitalSurgeAgent.API.Dtos;

/// <summary>Lightweight state info for a negotiation session (used by the web chat UI).</summary>
public sealed class SessionStateResponse
{
    public string SessionStatus { get; set; } = "";
    public int RemainingNeeded { get; set; }
    public int DeclineCount { get; set; }
    public int MaxDeclines { get; set; } = 3;
    public bool ShouldClose { get; set; }
    public string? CloseReason { get; set; }
}
