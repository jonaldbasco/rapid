using System.Collections.Concurrent;
using HospitalSurgeAgent.Core.Abstractions;

namespace HospitalSurgeAgent.API;

/// <summary>
/// Temporary in-memory conversation store (replace later with DB).
/// </summary>
public sealed class InMemoryConversationStore : IConversationStore
{
    private readonly ConcurrentDictionary<string, List<(string Sender, string Message)>> _sessions = new();

    public Task SaveMessageAsync(string sessionId, string sender, string message)
    {
        var conversation = _sessions.GetOrAdd(sessionId, _ => new List<(string, string)>());
        conversation.Add((sender, message));
        return Task.CompletedTask;
    }

    public Task<List<(string Sender, string Message)>> GetConversationAsync(string sessionId)
    {
        var conversation = _sessions.GetOrAdd(sessionId, _ => new List<(string, string)>());
        return Task.FromResult(conversation);
    }
}
