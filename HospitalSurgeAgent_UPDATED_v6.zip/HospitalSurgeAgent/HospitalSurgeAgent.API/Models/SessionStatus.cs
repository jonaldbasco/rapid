namespace HospitalSurgeAgent.API.Models;

/// <summary>
/// Status of a staff negotiation session.
/// </summary>
public enum SessionStatus
{
    /// <summary>Invite was sent and we are waiting for staff action.</summary>
    Offered,

    /// <summary>Staff opened the link or replied.</summary>
    Engaged,

    /// <summary>Staff accepted; pending unit manager confirmation/selection.</summary>
    AcceptedPendingManager,

    /// <summary>Unit manager confirmed this staff member for the schedule.</summary>
    Confirmed,

    /// <summary>Staff declined after all negotiation levels or explicitly declined.</summary>
    Declined,

    /// <summary>Session closed because the campaign was filled/closed by leadership.</summary>
    Closed
}
