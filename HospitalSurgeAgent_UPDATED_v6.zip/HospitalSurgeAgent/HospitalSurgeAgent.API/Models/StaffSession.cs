namespace HospitalSurgeAgent.API.Models;

/// <summary>
/// A single staff member's negotiation session (identified by a short link code).
/// </summary>
public sealed class StaffSession
{
    /// <summary>
    /// Short code used in the user-friendly link: /n/{Code}
    /// We also use this as the conversation store sessionId.
    /// </summary>
    public string Code { get; init; } = "";

    /// <summary>Recipient we contacted (email address in this demo).</summary>
    public string Recipient { get; init; } = "";

    /// <summary>Current negotiation status.</summary>
    public SessionStatus Status { get; set; } = SessionStatus.Offered;

    /// <summary>How many times this staff member has declined so far.</summary>
    public int DeclineCount { get; set; }

    /// <summary>Premium percent that was offered when the staff accepted (0/20/40). Null if not accepted.</summary>
    public int? AcceptedPremiumPercent { get; set; }

    /// <summary>When the staff accepted (UTC).</summary>
    public DateTime? AcceptedUtc { get; set; }

    /// <summary>When the manager confirmed (UTC).</summary>
    public DateTime? ConfirmedUtc { get; set; }

public DateTime CreatedUtc { get; init; } = DateTime.UtcNow;
    public DateTime LastActivityUtc { get; set; } = DateTime.UtcNow;
}
