using System.Collections.Concurrent;
using System.Linq;

namespace HospitalSurgeAgent.API.Models;

/// <summary>
/// A surge staffing "campaign" that tries to recruit N staff.
/// The campaign invites staff by notification (email in this demo) and tracks who accepts/declines.
/// </summary>
public sealed class SurgeCampaign
{
    public string Id { get; init; } = Guid.NewGuid().ToString();
    public string StaffGroup { get; init; } = "";
    public string Situation { get; init; } = "";
    public int SurgeRiskLevel { get; init; }
    public int RequiredStaff { get; init; }

    public string HospitalName { get; init; } = "";
    public string UnitName { get; init; } = "";
    public DateTimeOffset? IncidentDateTime { get; init; }
    public int? AdmissionsLastHour { get; init; }
    public string AdmissionReason { get; init; } = "";
    public string ExpectedSurgeWindow { get; init; } = "";
    public string ShiftSchedule { get; init; } = "";

    /// <summary>Final premium applied to ALL confirmed staff (set when campaign is finalized).</summary>
    public int? FinalPremiumPercent { get; set; }

    public DateTime? FinalizedUtc { get; set; }

    /// <summary>
    /// The full list of recipients in the order we will invite.
    /// In this demo, these are email addresses.
    /// </summary>
    public List<string> Recipients { get; init; } = new();

    /// <summary>Index of the next recipient to invite.</summary>
    public int NextInviteIndex { get; set; }

    public DateTime CreatedUtc { get; init; } = DateTime.UtcNow;

    /// <summary>Sessions created so far (keyed by short code).</summary>
    public ConcurrentDictionary<string, StaffSession> Sessions { get; } = new();

    /// <summary>
    /// How many staff have accepted so far.
    ///
    /// IMPORTANT:
    /// This is derived from session status so it cannot be double-counted.
    /// (e.g., if the same staff presses "Accept" twice).
    /// </summary>
    public int PendingAcceptCount => Sessions.Values.Count(s => s.Status == SessionStatus.AcceptedPendingManager);

    public int ConfirmedCount => Sessions.Values.Count(s => s.Status == SessionStatus.Confirmed);

    /// <summary>True if we already have enough accepts.</summary>
    public bool IsFilled => ConfirmedCount >= RequiredStaff;
}
