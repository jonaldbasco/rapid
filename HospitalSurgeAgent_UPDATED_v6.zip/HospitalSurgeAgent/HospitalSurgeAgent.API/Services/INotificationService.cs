namespace HospitalSurgeAgent.API.Services;

/// <summary>
/// Sends notifications to staff.
/// 
/// In this simplified demo we support:
/// - "Outbox" (test mode): writes messages to /outbox
/// - "Gmail SMTP" (real mode): sends email via smtp.gmail.com
/// </summary>
public interface INotificationService
{
    /// <summary>
    /// Sends a notification.
    /// 
    /// Where it comes from:
    /// - SurgeCampaignService when starting a campaign or inviting the next staff member.
    /// 
    /// Where it goes:
    /// - Either into the Outbox (test), or out to real email (Gmail SMTP).
    /// </summary>
    Task SendAsync(string to, string subject, string body);
}
