namespace HospitalSurgeAgent.API.Services;

/// <summary>
/// Default notification implementation for development.
/// 
/// Instead of sending a real SMS, it records the message to <see cref="OutboxService"/>.
/// This lets you test "sending" from Swagger without any external accounts.
/// </summary>
public sealed class OutboxNotificationService : INotificationService
{
    private readonly OutboxService _outbox;

    public OutboxNotificationService(OutboxService outbox)
    {
        _outbox = outbox;
    }

    public Task SendAsync(string to, string subject, string body)
    {
        // In test mode, we just add to the outbox.
        _outbox.Add(to, subject, body);
        return Task.CompletedTask;
    }
}
