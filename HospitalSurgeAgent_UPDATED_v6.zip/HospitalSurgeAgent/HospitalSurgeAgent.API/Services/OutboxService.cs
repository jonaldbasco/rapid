using System.Collections.Concurrent;

namespace HospitalSurgeAgent.API.Services;

/// <summary>
/// Test-friendly "outbox".
/// 
/// Instead of sending real messages in development, we store "sent messages" here
/// so you can verify the correct message body and link in Swagger.
/// 
/// You can later replace the notification implementation with any real provider.
/// </summary>
public sealed class OutboxService
{
    private readonly ConcurrentQueue<OutboxMessage> _messages = new();

    /// <summary>
    /// Adds a message to the outbox.
    /// This simulates a notification being sent.
    /// </summary>
    public void Add(string to, string subject, string body)
    {
        _messages.Enqueue(new OutboxMessage
        {
            To = to,
            Subject = subject,
            Body = body,
            CreatedUtc = DateTime.UtcNow
        });
    }

    /// <summary>
    /// Returns all messages currently in the outbox (oldest first).
    /// </summary>
    public IReadOnlyList<OutboxMessage> GetAll()
        => _messages.ToList();
}

/// <summary>Represents a single "sent" message (SMS/email) in test mode.</summary>
public sealed class OutboxMessage
{
    public string To { get; set; } = "";
    public string Subject { get; set; } = "";
    public string Body { get; set; } = "";
    public DateTime CreatedUtc { get; set; }
}
