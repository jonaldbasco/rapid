﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HospitalSurgeAgent.Core.Abstractions;

namespace HospitalSurgeAgent.Console
{
    public class InMemoryConversationStore : IConversationStore
    {
        private readonly Dictionary<string, List<(string Sender, string Message)>>
            _conversations = new();

        public Task SaveMessageAsync(string sessionId, string sender, string message)
        {
            if (!_conversations.ContainsKey(sessionId))
                _conversations[sessionId] = new();

            _conversations[sessionId].Add((sender, message));

            return Task.CompletedTask;
        }

        public Task<List<(string Sender, string Message)>>
            GetConversationAsync(string sessionId)
        {
            if (!_conversations.ContainsKey(sessionId))
                return Task.FromResult(new List<(string, string)>());

            return Task.FromResult(_conversations[sessionId]);
        }
    }

}
