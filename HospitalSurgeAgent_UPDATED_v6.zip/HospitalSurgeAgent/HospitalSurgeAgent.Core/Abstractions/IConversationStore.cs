﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalSurgeAgent.Core.Abstractions
{
    public interface IConversationStore
    {
        Task SaveMessageAsync(string sessionId, string sender, string message);

        Task<List<(string Sender, string Message)>>
            GetConversationAsync(string sessionId);
    }

}
