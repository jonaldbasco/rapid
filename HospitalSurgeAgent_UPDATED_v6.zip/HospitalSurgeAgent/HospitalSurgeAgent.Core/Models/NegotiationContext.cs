namespace HospitalSurgeAgent.Core.Models;

/// <summary>
/// Context used by the negotiation agent to craft the next message.
/// This is the data the agent needs to understand the surge situation.
/// </summary>
public class NegotiationContext
{
    /// <summary>The staff group being contacted (e.g., ICU Nurses).</summary>
    public string StaffGroup { get; set; } = "";

    /// <summary>How many times this staff member has declined so far.</summary>
    public int DeclineCount { get; set; }

    /// <summary>
    /// A simple 1-5 risk scale where 5 is most urgent.
    /// (Example: a major accident surge might be 5.)
    /// </summary>
    public int SurgeRiskLevel { get; set; }

    /// <summary>Short description of the current situation (what happened, why urgent).</summary>
    public string Situation { get; set; } = "";

    /// <summary>Whether we still need additional staff for the surge.</summary>
    public bool IsUnderStaffed { get; set; }
    /// <summary>Hospital name (optional, used in briefings).</summary>
    public string HospitalName { get; set; } = "";

    /// <summary>Target unit/department (e.g., Burn Unit, ICU).</summary>
    public string UnitName { get; set; } = "";

    /// <summary>When the incident started / was reported (local or UTC).</summary>
    public DateTimeOffset? IncidentDateTime { get; set; }

    /// <summary>Approx admissions in the last hour (optional).</summary>
    public int? AdmissionsLastHour { get; set; }

    /// <summary>Reason for admission / incident summary (optional, overrides Situation phrasing).</summary>
    public string AdmissionReason { get; set; } = "";

    /// <summary>Expected surge time window (e.g., "next 2–4 hours").</summary>
    public string ExpectedSurgeWindow { get; set; } = "";

    /// <summary>Scheduled shift text (e.g., "tomorrow from 7am–7pm").</summary>
    public string ShiftSchedule { get; set; } = "";


    /// <summary>Used by some flows to track time since the last message.</summary>
    public DateTime LastMessageUtc { get; set; } = DateTime.UtcNow;
}

