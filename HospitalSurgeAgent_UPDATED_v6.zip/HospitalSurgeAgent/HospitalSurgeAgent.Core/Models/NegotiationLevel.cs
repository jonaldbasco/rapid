﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalSurgeAgent.Core.Models;

public class NegotiationLevel
{
    public int Level { get; set; }
    public int IncentiveIncreasePercent { get; set; }
    public string Tone { get; set; } = "";
    public bool RequiresApproval { get; set; }
}
