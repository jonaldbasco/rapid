﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalSurgeAgent.Core.Models
{
    public class NegotiationSession
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();

        public string StaffGroup { get; set; }

        public int DeclineCount { get; set; }

        public bool IsClosed { get; set; }

        public List<string> Messages { get; set; } = new();
    }

}
