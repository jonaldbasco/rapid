﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HospitalSurgeAgent.Core.Models;

namespace HospitalSurgeAgent.Core.Rules;

public class NegotiationRulesEngine
{
    private const int MAX_NEGOTIATION_LEVEL = 3;
    private const int RESPONSE_TIMEOUT_MINUTES = 30;

    private readonly List<NegotiationLevel> _levels = new()
    {
        new NegotiationLevel
        {
            Level = 1,
            IncentiveIncreasePercent = 0,
            Tone = "Professional clinical briefing (no premium mentioned at level 1)",
            RequiresApproval = false
        },
        new NegotiationLevel
        {
            Level = 2,
            IncentiveIncreasePercent = 20,
            Tone = "Professional and direct (premium offer wording required)",
            RequiresApproval = false
        },
        new NegotiationLevel
        {
            Level = 3,
            IncentiveIncreasePercent = 40,
            Tone = "Urgent but ethical (premium offer wording required)",
            RequiresApproval = true
        }
    };

    // ✅ Caps escalation automatically
    public NegotiationLevel GetLevel(int declineCount)
    {
        var levelNumber = Math.Min(declineCount + 1, MAX_NEGOTIATION_LEVEL);

        return _levels.First(l => l.Level == levelNumber);
    }

    // ✅ Check if negotiation should escalate due to timeout
    public bool HasTimedOut(DateTime lastMessageUtc)
    {
        return DateTime.UtcNow - lastMessageUtc
               > TimeSpan.FromMinutes(RESPONSE_TIMEOUT_MINUTES);
    }

    // ✅ Determines if negotiation should continue
    public bool ShouldContinueNegotiation(
        int declineCount,
        bool isUnderStaffed)
    {
        if (!isUnderStaffed)
            return false;

        return declineCount < MAX_NEGOTIATION_LEVEL;
    }

    // ⭐ Optional but VERY powerful
    // Lets YOU adjust compensation dynamically
    public int CalculateDynamicIncentive(
        double surgeSeverity,   // 0.0 → 1.0
        int declineCount)
    {
        var baseLevel = GetLevel(declineCount);

        // Add extra % if surge is critical
        if (surgeSeverity > 0.9)
            return baseLevel.IncentiveIncreasePercent + 10;

        if (surgeSeverity > 0.75)
            return baseLevel.IncentiveIncreasePercent + 5;

        return baseLevel.IncentiveIncreasePercent;
    }
}


