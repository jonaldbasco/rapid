﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using OpenAI.Chat;

namespace HospitalSurgeAgent.Core.Services;

public class OpenAIService
{
    private readonly ChatClient? _chat;
    private readonly bool _enabled;

    public OpenAIService(string apiKey)
    {
        _enabled = !string.IsNullOrWhiteSpace(apiKey);
        _chat = _enabled ? new ChatClient("gpt-4.1-mini", apiKey) : null;
    }

    

    private static string BuildTimeSinceText(DateTimeOffset incidentDateTime)
    {
        var now = DateTimeOffset.Now;
        var hours = Math.Max(0.0, (now - incidentDateTime).TotalHours);

        if (hours < 1.0)
            return "Within the last hour";

        var whole = (int)Math.Floor(hours);

        return whole == 1 ? "Within the last 1 hour" : $"Within the last {whole} hours";
    }

/// <summary>
    /// Generates a short clinical briefing paragraph used in the initial email outreach.
    /// If OpenAI is not configured, returns a deterministic safe fallback.
    /// </summary>
    public async Task<string> GenerateClinicalBriefingAsync(
        DateTimeOffset incidentDateTime,
        string timeSinceText,
        int? admissionsLastHour,
        string hospitalName,
        string admissionReason,
        string unitName,
        string expectedSurgeWindow)
    {
        var admissionsText = admissionsLastHour.HasValue ? admissionsLastHour.Value.ToString() : "several";
        var hospital = string.IsNullOrWhiteSpace(hospitalName) ? "the hospital" : hospitalName.Trim();
        var unit = string.IsNullOrWhiteSpace(unitName) ? "the unit" : unitName.Trim();
        var reason = string.IsNullOrWhiteSpace(admissionReason) ? "an acute surge event" : admissionReason.Trim();
        var window = string.IsNullOrWhiteSpace(expectedSurgeWindow) ? "the next few hours" : expectedSurgeWindow.Trim();

        // Deterministic fallback (used when OPENAI_API_KEY is not set).
        var fallback = $"{incidentDateTime:yyyy-MM-dd HH:mm zzz} {timeSinceText}, {admissionsText} people have been admitted to the {hospital} Emergency Department due to {reason}. " +
                       $"We’re expecting a surge at the {unit} within {window}. " +
                       "Current capacity may be exceeded, creating a risk of delayed critical care and preventable patient harm.";

        if (!_enabled || _chat == null)
            return fallback;

        var messages = new List<ChatMessage>
        {
            ChatMessage.CreateSystemMessage(
"""
You are a hospital surge staffing coordinator writing a short clinical briefing.

Requirements:
- Write 2 to 4 sentences, single paragraph.
- Professional nursing/clinical tone.
- Do NOT use graphic language (avoid words like "disfigurement").
- Do NOT invent numbers, times, names, or details; use only the provided inputs.
- No bullets, no markdown.
- Keep the meaning consistent, but vary wording slightly across calls.
- The paragraph MUST start with the provided incident timestamp and a "Within the last..." style clause.
"""),
            ChatMessage.CreateUserMessage(
$"""
Incident timestamp (must appear at the very start): {incidentDateTime:yyyy-MM-dd HH:mm zzz}
Time since (use exactly as provided): {timeSinceText}
Admissions in last hour: {admissionsText}
Hospital name: {hospital}
Admission reason: {reason}
Unit name: {unit}
Expected surge window: {window}
"""),
        };

        var options = new ChatCompletionOptions { Temperature = 0.4f };

        try
        {
            var response = await _chat.CompleteChatAsync(messages, options);
            var text = string.Join("",
                response.Value.Content
                    .Where(c => c.Text != null)
                    .Select(c => c.Text));

            return string.IsNullOrWhiteSpace(text) ? fallback : text.Trim();
        }
        catch
        {
            return fallback;
        }
    }

    /// <summary>
    /// Generates a negotiation message for a specific staff member/group.
    /// </summary>
    public async Task<string> GenerateNegotiationMessage(
        string staffGroup,
        int incentive,
        string tone,
        string situation,
        int surgeRiskLevel,
        string history,
        string hospitalName,
        string unitName,
        DateTimeOffset? incidentDateTime,
        int? admissionsLastHour,
        string admissionReason,
        string expectedSurgeWindow,
        string shiftSchedule)
    {

        var now = DateTimeOffset.Now;
        var inc = incidentDateTime;
        var hoursSince = inc.HasValue ? Math.Max(0.0, (now - inc.Value).TotalHours) : 0.0;
                var timeSinceText = inc.HasValue ? BuildTimeSinceText(inc.Value) : "Within the last hour";
        var admissionsText = admissionsLastHour.HasValue ? admissionsLastHour.Value.ToString() : "several";
        var reasonText = string.IsNullOrWhiteSpace(admissionReason) ? situation : admissionReason;
        var hospitalText = string.IsNullOrWhiteSpace(hospitalName) ? "the hospital" : hospitalName;
        var unitText = string.IsNullOrWhiteSpace(unitName) ? "the unit" : unitName;

        // If OpenAI isn't configured, fall back to a deterministic, policy-safe message.
        if (!_enabled || _chat == null)
        {
            if (incentive <= 0)
            {
                return $"{(incidentDateTime.HasValue ? incidentDateTime.Value.ToString("yyyy-MM-dd HH:mm zzz") + " " : string.Empty)}" +
                       $"{timeSinceText}, {admissionsText} people have been admitted to {hospitalText}'s Emergency Department due to {reasonText}. " +
                       $"We’re expecting a surge at {unitText} within {(string.IsNullOrWhiteSpace(expectedSurgeWindow) ? "the next few hours" : expectedSurgeWindow)}. " +
                       "Current capacity may be exceeded, creating a risk of delayed critical care and preventable patient harm. " +
                       (string.IsNullOrWhiteSpace(shiftSchedule) || shiftSchedule == "N/A"
                           ? "Can you come in to help cover the surge?"
                           : $"Can we secure your commitment to come to work {shiftSchedule} at the {unitText}?");
            }

            return $"We value your time and energy. We’re offering a premium of {incentive}% on top of your hourly rate. " +
                   (string.IsNullOrWhiteSpace(shiftSchedule) || shiftSchedule == "N/A"
                       ? "Can you come in to help cover the surge?"
                       : $"Can we secure your commitment to come to work {shiftSchedule} at the {unitText}?");
        }

        var messages = new List<ChatMessage>
    {
        ChatMessage.CreateSystemMessage(
"""
You are an AI assistant supporting hospital leadership during staffing shortages and patient surges.

You are speaking as the hospital surge staffing coordinator.
Never invent or roleplay a staff message.
Do not prefix your output with labels like "Staff:" or "Agent:".

Your communication must always be:

- Professional
- Ethical
- Non-coercive
- Legally cautious
- Respectful of staff wellbeing
- Supportive, never threatening

You are NOT allowed to pressure employees.

Focus on collaboration, patient safety, and shared responsibility.
Be conversational and helpful.
Keep messages concise, but you may exceed 120 words when answering staff questions.
"""
        ),

        ChatMessage.CreateUserMessage(
$"""
Context
---
Hospital: {hospitalText}
Unit: {unitText}
Incident time: {(incidentDateTime.HasValue ? incidentDateTime.Value.ToString("yyyy-MM-dd HH:mm zzz") : "N/A")}
Admissions in last hour: {(admissionsLastHour.HasValue ? admissionsLastHour.Value.ToString() : "N/A")}
Admission reason: {(string.IsNullOrWhiteSpace(admissionReason) ? situation : admissionReason)}
Expected surge window: {(string.IsNullOrWhiteSpace(expectedSurgeWindow) ? "N/A" : expectedSurgeWindow)}
Shift schedule: {(string.IsNullOrWhiteSpace(shiftSchedule) ? "N/A" : shiftSchedule)}

Situation: {situation}
Urgency (1-5): {surgeRiskLevel}/5
Staff Group: {staffGroup}

Current offer (if they agree to help):
- Premium to add to hourly rate: {incentive}% (0 means no premium / standard pay)
- Overtime and applicable differentials follow hospital policy.

Tone guidance: {tone}

Conversation history (most recent lines last):
{history}

Task
---
Continue the conversation with the staff member as a professional nurse/clinical coordinator briefing the situation.

Rules:
1) Do not invent staff messages. Do not prefix your output with labels like "Staff:" or "Agent:".
2) If incentive == 0 (level 1), DO NOT mention any percentage or premium. Speak as standard pay per policy.
3) If incentive > 0, your FIRST sentence must be exactly:
   "We value your time and energy. We’re offering a premium of {incentive}% on top of your hourly rate."
4) Do NOT mention how many staff are needed.
5) Always include a clear ask to cover the shift in this exact structure near the end:
   "Can we secure your commitment to come to work {shiftSchedule} at the {unitText}?"
   - If shiftSchedule or unitName are N/A, fall back to: "Can you come in to help cover the surge?"
6) If the staff member asked a question, answer it briefly first, then restate the ask.
7) Ask at most ONE clarifying question.
8) Keep it ethical and non-coercive. No guilt, no threats.

If there is no staff message yet, produce an initial outreach that starts with:
"{(incidentDateTime.HasValue ? incidentDateTime.Value.ToString("yyyy-MM-dd HH:mm zzz") : "")} {timeSinceText}, {admissionsText} people have been admitted to the {hospitalText} Emergency Department to {reasonText}."
Then explain expected surge at the unit, the patient safety risk, and the shift ask.
"""
)};
        var options = new ChatCompletionOptions
        {
            Temperature = 0.4f
        };


        if (!_enabled || _chat == null)
        {
            // Safe fallback if OpenAI is not configured.
            // Keep it short and rule-consistent; avoid mentioning incentives when incentive==0.
            if (incentive <= 0)
            {
                return $"We’re coordinating surge coverage for {unitText} at {hospitalText}. Can we secure your commitment to come to work {shiftSchedule} at the {unitText}?";
            }

            return $"We value your time and energy. We’re offering a premium of {incentive}% on top of your hourly rate. Can we secure your commitment to come to work {shiftSchedule} at the {unitText}?";
        }

        var response = await _chat.CompleteChatAsync(messages,options);

        return string.Join("",
            response.Value.Content
                .Where(c => c.Text != null)
                .Select(c => c.Text));

    }

}
