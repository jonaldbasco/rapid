namespace HospitalSurgeAgent.API.Dtos;

public sealed class ManagerConfirmRequest
{
    /// <summary>Session link codes to confirm/schedule.</summary>
    public List<string> Codes { get; set; } = new();
}
