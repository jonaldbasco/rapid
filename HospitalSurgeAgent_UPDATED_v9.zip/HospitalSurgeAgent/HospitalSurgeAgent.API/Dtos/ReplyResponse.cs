namespace HospitalSurgeAgent.API.Dtos;

/// <summary>Response after posting a staff reply.</summary>
public sealed class ReplyResponse
{
    /// <summary>The next message the agent would send to this staff member.</summary>
    public string AgentMessage { get; set; } = "";

    /// <summary>Current status of this staff session (Accepted/Declined/Open/Closed).</summary>
    public string SessionStatus { get; set; } = "";

    /// <summary>How many accepts are still needed for the campaign.</summary>
    public int RemainingNeeded { get; set; }

    /// <summary>How many times this staff member has declined so far.</summary>
    public int DeclineCount { get; set; }

    /// <summary>Maximum number of declines before this session is finalized.</summary>
    public int MaxDeclines { get; set; } = 3;

    /// <summary>
    /// True when this session is finished (Accepted / Declined / Closed).
    /// The web chat can disable inputs and tell the staff they can close the page.
    /// </summary>
    public bool ShouldClose { get; set; }

    /// <summary>
    /// Optional human-readable reason shown in the UI when <see cref="ShouldClose"/> is true.
    /// </summary>
    public string? CloseReason { get; set; }
}
