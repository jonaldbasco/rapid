namespace HospitalSurgeAgent.API.Dtos;

/// <summary>
/// Request to start a surge staffing campaign.
/// This sends invitations to ALL unique recipients in <see cref="EmailAddresses"/>.
/// Unit managers will later confirm/select who is actually scheduled.
/// </summary>
public sealed class StartSurgeRequest
{
    /// <summary>Example: "ICU Nurses" or "Float Pool".</summary>
    public string StaffGroup { get; set; } = "";

    /// <summary>Hospital name (optional).</summary>
    public string HospitalName { get; set; } = "";

    /// <summary>Target unit/department (e.g., "Burn Unit").</summary>
    public string UnitName { get; set; } = "";

    /// <summary>
    /// When the incident started / was reported (optional).
    /// If omitted, we will treat the incident as "now".
    /// </summary>
    public DateTimeOffset? IncidentDateTime { get; set; }

    /// <summary>Approx admissions in the last hour (optional).</summary>
    public int? AdmissionsLastHour { get; set; }

    /// <summary>Reason for admission / incident summary (optional).</summary>
    public string AdmissionReason { get; set; } = "";

    /// <summary>Expected surge time window (e.g., "next 2–4 hours") (optional).</summary>
    public string ExpectedSurgeWindow { get; set; } = "";

    /// <summary>Scheduled shift text (e.g., "tomorrow from 7am–7pm") (optional).</summary>
    public string ShiftSchedule { get; set; } = "";

    /// <summary>
    /// A short description of what happened and why you need help.
    /// Example: "Multi-vehicle accident. Need additional ICU coverage." 
    /// </summary>
    public string Situation { get; set; } = "";

    /// <summary>Simple 1-5 urgency scale (5 = most urgent).</summary>
    public int SurgeRiskLevel { get; set; }

    /// <summary>
    /// How many staff you ultimately need to confirm/schedule.
    /// NOTE: Invitations are still sent to all recipients; managers will confirm selections.
    /// </summary>
    public int RequiredStaff { get; set; }

    /// <summary>
    /// Email addresses to contact.
    /// IMPORTANT: One staff member should appear only once.
    /// This API de-duplicates addresses (case-insensitive).
    /// </summary>
    public List<string> EmailAddresses { get; set; } = new();
}
