namespace HospitalSurgeAgent.API.Dtos;

/// <summary>Response returned after starting a surge campaign.</summary>
public sealed class StartSurgeResponse
{
    /// <summary>Campaign ID you can use to query status.</summary>
    public string CampaignId { get; set; } = "";

    /// <summary>How many staff are required to confirm/schedule.</summary>
    public int RequiredStaff { get; set; }

    /// <summary>How many staff have been confirmed by the unit manager so far (starts at 0).</summary>
    public int ConfirmedStaff { get; set; }

    /// <summary>How many staff have accepted but are awaiting manager confirmation.</summary>
    public int PendingAcceptedStaff { get; set; }

    /// <summary>Backward-compatible alias (same as ConfirmedStaff).</summary>
    public int AcceptedStaff { get; set; }

    /// <summary>How many invitations were sent immediately.</summary>
    public int InvitationsSent { get; set; }

    /// <summary>How many more confirmations are still needed.</summary>
    public int RemainingNeeded { get; set; }

    /// <summary>Details for each invite (number + short link).</summary>
    public List<InviteInfo> Invites { get; set; } = new();
}

/// <summary>Per-recipient invite information.</summary>
public sealed class InviteInfo
{
    /// <summary>The recipient we contacted (email address in this demo).</summary>
    public string Recipient { get; set; } = "";
    public string LinkCode { get; set; } = "";
    public string LinkUrl { get; set; } = "";
}
