using System.Net;
using System.Reflection;
using System.Text.Json;
using HospitalSurgeAgent.API;
using HospitalSurgeAgent.API.Dtos;
using HospitalSurgeAgent.API.Services;
using HospitalSurgeAgent.Core.Agents;
using HospitalSurgeAgent.Core.Abstractions;
using HospitalSurgeAgent.Core.Services;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);

// -------------------------------
// Dependency Injection (DI)
// -------------------------------

// OpenAI client used by SurgeNegotiationAgent
builder.Services.AddSingleton<OpenAIService>(_ =>
{
    // Where it comes from:
    // - You set an environment variable OPENAI_API_KEY on your machine.
    // Where it goes:
    // - Used to generate negotiation messages.
    var apiKey = Environment.GetEnvironmentVariable("OPENAI_API_KEY");
    // Allow the API to run even when the key is missing; OpenAIService will fall back
    // to deterministic templates for email/chat generation.
    return new OpenAIService(apiKey ?? "");
});

// Conversation store (in-memory for now) used to keep the chat history per short link code.
builder.Services.AddSingleton<IConversationStore, InMemoryConversationStore>();

// Negotiation agent (uses OpenAI + conversation store)
builder.Services.AddSingleton<SurgeNegotiationAgent>();

// Outbox stores "sent" messages so you can test without a real provider.
builder.Services.AddSingleton<OutboxService>();

// Notification sender:
// - If Gmail SMTP env vars are set, sends real email.
// - Otherwise falls back to the Outbox.
builder.Services.AddSingleton<INotificationService>(sp =>
{
    var cfg = sp.GetRequiredService<IConfiguration>();
    var outbox = sp.GetRequiredService<OutboxService>();

    var user = Environment.GetEnvironmentVariable("GMAIL_SMTP_USER") ?? cfg["Smtp:User"];
    var pass = Environment.GetEnvironmentVariable("GMAIL_SMTP_PASS");

    if (!string.IsNullOrWhiteSpace(user) && !string.IsNullOrWhiteSpace(pass))
        return new GmailSmtpNotificationService(cfg, outbox);

    return new OutboxNotificationService(outbox);
});

// Main campaign orchestrator.
builder.Services.AddSingleton<SurgeCampaignService>();

// -------------------------------
// Swagger / OpenAPI
// -------------------------------

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "HospitalSurgeAgent API",
        Version = "v1",
        Description = "Start a surge campaign, send staff email invites (Gmail SMTP or test outbox), and negotiate via a short chat link."
    });

    // Include XML docs (from <GenerateDocumentationFile>true</GenerateDocumentationFile>)
    var xmlName = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
    var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlName);
    if (File.Exists(xmlPath))
        c.IncludeXmlComments(xmlPath);
});

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("/swagger/v1/swagger.json", "HospitalSurgeAgent API v1");
    c.DocumentTitle = "HospitalSurgeAgent Swagger";
});

app.UseHttpsRedirection();
app.UseStaticFiles();

// -------------------------------
// Helper: compute a base URL to build clickable links in the notification.
// -------------------------------
static string GetBaseUrl(HttpRequest req)
{
    // If you are using a public tunnel (e.g., ngrok), set PUBLIC_BASE_URL.
    // This ensures the invite link is usable from other computers/phones.
    var publicBase = Environment.GetEnvironmentVariable("PUBLIC_BASE_URL");
    if (!string.IsNullOrWhiteSpace(publicBase))
        return publicBase.Trim().TrimEnd('/');

    // Fallback: use the current request host.
    // Example output: https://localhost:5001
    return $"{req.Scheme}://{req.Host}";
}

// -------------------------------
// Helper: load the web chat template from wwwroot/chat.html
// -------------------------------
static string LoadChatTemplate(WebApplication app)
{
    var webRoot = app.Environment.WebRootPath;
    if (string.IsNullOrWhiteSpace(webRoot))
        webRoot = Path.Combine(app.Environment.ContentRootPath, "wwwroot");

    var path = Path.Combine(webRoot, "chat.html");
    if (!File.Exists(path))
        throw new FileNotFoundException($"Chat template not found: {path}");

    return File.ReadAllText(path);
}

// -------------------------------
// API Endpoints
// -------------------------------

// 1) Start a surge campaign
//    - You provide RequiredStaff + email addresses.
//    - The system sends the first N invites (N=RequiredStaff).
app.MapPost("/surge/start", async (StartSurgeRequest request, SurgeCampaignService campaigns, HttpRequest http) =>
{
    try
    {
        var baseUrl = GetBaseUrl(http);
        var result = await campaigns.StartAsync(request, baseUrl);
        return Results.Ok(result);
    }
    catch (ArgumentException ex)
    {
        // Return a friendly 400 with the reason (e.g., not enough unique recipients).
        return Results.BadRequest(new { error = ex.Message });
    }
}).WithName("StartSurgeCampaign");

// 2) Check campaign status
app.MapGet("/surge/{campaignId}", (string campaignId, SurgeCampaignService campaigns) =>
{
    try
    {
        var status = campaigns.GetStatus(campaignId);
        return Results.Ok(status);
    }
    catch (KeyNotFoundException ex)
    {
        return Results.NotFound(new { error = ex.Message });
    }
}).WithName("GetSurgeCampaignStatus");
// 2b) List pending accepts (unit manager view)
app.MapGet("/surge/{campaignId}/pending-accepts", (string campaignId, SurgeCampaignService campaigns) =>
{
    try
    {
        return Results.Ok(campaigns.GetPendingAccepts(campaignId));
    }
    catch (KeyNotFoundException ex)
    {
        return Results.NotFound(new { error = ex.Message });
    }
}).WithName("GetPendingAccepts");

// 2c) Unit manager confirms/schedules selected staff
app.MapPost("/surge/{campaignId}/confirm", async (string campaignId, ManagerConfirmRequest req, SurgeCampaignService campaigns) =>
{
    try
    {
        var status = await campaigns.ManagerConfirmAsync(campaignId, req.Codes);
        return Results.Ok(status);
    }
    catch (KeyNotFoundException ex)
    {
        return Results.NotFound(new { error = ex.Message });
    }
    catch (ArgumentException ex)
    {
        return Results.BadRequest(new { error = ex.Message });
    }
}).WithName("ManagerConfirm");


// 3) View the outbox (what messages were "sent")
app.MapGet("/outbox", (OutboxService outbox) => Results.Ok(outbox.GetAll()))
   .WithName("GetOutbox");

// 4) Staff opens the short link
//    - This returns a tiny web chat UI.
app.MapGet("/n/{code}", (string code, SurgeCampaignService campaigns) =>
{
    // Record that the staff opened the link.
    // If the app was restarted (in-memory campaigns), the code may be unknown.
    try
    {
        campaigns.MarkOpened(code);
    }
    catch (KeyNotFoundException)
    {
        // IMPORTANT: use named parameter 'statusCode' so the correct overload is used.
        return Results.Content(
            "<h3>Invite link expired</h3><p>This invite link is no longer valid (the server restarted or the campaign was cleared). Please request a new invite.</p>",
            "text/html",
            statusCode: StatusCodes.Status404NotFound);
    }

    var template = LoadChatTemplate(app);

    // Replace placeholders safely.
    var html = template
        .Replace("__CODE_DISPLAY__", WebUtility.HtmlEncode(code))
        .Replace("__CODE_JSON__", JsonSerializer.Serialize(code));

    return Results.Content(html, "text/html");
}).WithName("OpenNegotiationLink");

// 5) Staff posts a reply (accept/decline/question)
app.MapPost("/negotiations/{code}/reply", async (string code, ReplyRequest req, SurgeCampaignService campaigns, HttpRequest http) =>
{
    var baseUrl = GetBaseUrl(http);
    try
    {
        var response = await campaigns.HandleReplyAsync(code, req.Message, baseUrl);
        return Results.Ok(response);
    }
    catch (KeyNotFoundException ex)
    {
        return Results.NotFound(new { error = ex.Message });
    }
}).WithName("PostNegotiationReply");

// 6) Read chat history (used by the tiny web UI)
app.MapGet("/negotiations/{code}/history", async (string code, IConversationStore store) =>
{
    // Where it comes from:
    // - Messages saved by SurgeNegotiationAgent.
    // Where it goes:
    // - Returned to the web UI to render the chat.
    var history = await store.GetConversationAsync(code);
    var payload = history.Select(h => new { sender = h.Sender, message = h.Message });
    return Results.Ok(payload);
}).WithName("GetNegotiationHistory");

// 7) Read session state (decline count, remaining needed, etc.)
//    Used by the web UI so it can:
//    - only prompt confirmation on the *final* decline
//    - disable the page when the session is closed
app.MapGet("/negotiations/{code}/state", (string code, SurgeCampaignService campaigns) =>
{
    try
    {
        return Results.Ok(campaigns.GetSessionState(code));
    }
    catch (KeyNotFoundException ex)
    {
        return Results.NotFound(new { error = ex.Message });
    }
}).WithName("GetNegotiationState");

app.Run();
