using MailKit.Net.Smtp;
using MailKit.Security;
using MimeKit;

namespace HospitalSurgeAgent.API.Services;

/// <summary>
/// Sends REAL email using Gmail SMTP.
/// 
/// How to configure (Windows example):
///   setx GMAIL_SMTP_USER "yourgmail@gmail.com"
///   setx GMAIL_SMTP_PASS "your_app_password"
/// 
/// Gmail requires an "App Password" (not your normal login password) when 2FA is enabled.
/// 
/// If the environment variables are NOT set, the DI wiring will fall back to <see cref="OutboxNotificationService" />.
/// </summary>
public sealed class GmailSmtpNotificationService : INotificationService
{
    private readonly IConfiguration _cfg;
    private readonly OutboxService _outbox;

    public GmailSmtpNotificationService(IConfiguration cfg, OutboxService outbox)
    {
        _cfg = cfg;
        _outbox = outbox;
    }

    /// <summary>
    /// Sends an email via smtp.gmail.com.
    /// Also writes the message into /outbox so you can inspect what was sent.
    /// </summary>
    public async Task SendAsync(string to, string subject, string body)
    {
        // Always log what we attempted to send (useful for debugging).
        _outbox.Add(to, subject, body);

        // Read Gmail SMTP credentials from environment variables.
        // (User requested the password to come from env var.)
        var user = Environment.GetEnvironmentVariable("GMAIL_SMTP_USER") ?? _cfg["Smtp:User"];
        var pass = Environment.GetEnvironmentVariable("GMAIL_SMTP_PASS");

        if (string.IsNullOrWhiteSpace(user) || string.IsNullOrWhiteSpace(pass))
        {
            // If credentials are missing, do not throw here.
            // The app will still work in Outbox mode.
            return;
        }

        // Optional settings (defaults work for Gmail).
        var host = _cfg["Smtp:Host"] ?? "smtp.gmail.com";
        var port = int.TryParse(_cfg["Smtp:Port"], out var p) ? p : 587;
        var from = Environment.GetEnvironmentVariable("GMAIL_SMTP_FROM")
                   ?? _cfg["Smtp:From"]
                   ?? user;

        var message = new MimeMessage();
        message.From.Add(MailboxAddress.Parse(from));
        message.To.Add(MailboxAddress.Parse(to));
        message.Subject = subject;
        message.Body = new TextPart("plain") { Text = body };

        using var smtp = new SmtpClient();
        await smtp.ConnectAsync(host, port, SecureSocketOptions.StartTls);
        await smtp.AuthenticateAsync(user, pass);
        await smtp.SendAsync(message);
        await smtp.DisconnectAsync(true);
    }
}
