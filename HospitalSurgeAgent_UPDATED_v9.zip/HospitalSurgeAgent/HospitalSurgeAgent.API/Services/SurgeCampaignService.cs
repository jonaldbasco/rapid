using System.Collections.Concurrent;
using System.Text;
using HospitalSurgeAgent.API.Dtos;
using HospitalSurgeAgent.API.Models;
using HospitalSurgeAgent.Core.Agents;
using HospitalSurgeAgent.Core.Abstractions;
using HospitalSurgeAgent.Core.Models;
using HospitalSurgeAgent.Core.Services;

namespace HospitalSurgeAgent.API.Services;

/// <summary>
/// Orchestrates the surge staffing campaign.
/// 
/// This is the "conductor" that:
/// - creates campaigns
/// - creates staff sessions (short links)
/// - sends invites (email or outbox)
/// - handles accepts/declines
/// - keeps inviting more staff until the required count is filled
/// </summary>
public sealed class SurgeCampaignService
{
    // Business rule: we offer up to 3 negotiation levels, and accept up to 3 explicit declines.
    private const int MaxDeclines = 3;
    private readonly ConcurrentDictionary<string, SurgeCampaign> _campaigns = new();
    private readonly ConcurrentDictionary<string, string> _codeToCampaignId = new();

    private readonly SurgeNegotiationAgent _agent;
    private readonly INotificationService _notifier;
    private readonly IConversationStore _store;
    private readonly OpenAIService _ai;

    public SurgeCampaignService(SurgeNegotiationAgent agent, INotificationService notifier, IConversationStore store, OpenAIService ai)
    {
        _agent = agent;
        _notifier = notifier;
        _store = store;
        _ai = ai;
    }

    /// <summary>
    /// Starts a campaign and immediately sends invites to ALL unique recipients.
    /// Unit managers will later confirm/select who is actually scheduled.
    /// </summary>
    public async Task<StartSurgeResponse> StartAsync(StartSurgeRequest request, string baseUrl)
    {
        // Validate the request shape first.
        ValidateStartRequest(request);

        // IMPORTANT (fix for duplicate emails/links):
        // We want ONE invite per staff member.
        // If the same email appears multiple times in the input list,
        // the old logic would invite the same person multiple times,
        // creating multiple emails and multiple short-link codes.
        //
        // So we normalize + de-duplicate the recipient list here.
        var uniqueRecipients = request.EmailAddresses
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Select(x => x.Trim())
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        // RequiredStaff cannot exceed the number of UNIQUE emails provided.
        // Otherwise we cannot invite "the other 4".
        if (uniqueRecipients.Count < request.RequiredStaff)
        {
            throw new ArgumentException(
                $"Not enough unique EmailAddresses. RequiredStaff={request.RequiredStaff} but you provided {uniqueRecipients.Count} unique email(s). " +
                "Provide more staff emails (or for testing Gmail, use plus-addressing like name+1@gmail.com, name+2@gmail.com, etc.).");
        }

        // Create a new campaign record.
        var campaign = new SurgeCampaign
        {
            StaffGroup = request.StaffGroup.Trim(),
            Situation = request.Situation.Trim(),
            SurgeRiskLevel = request.SurgeRiskLevel,
            RequiredStaff = request.RequiredStaff,

            HospitalName = request.HospitalName?.Trim() ?? "",
            UnitName = request.UnitName?.Trim() ?? "",
            IncidentDateTime = request.IncidentDateTime,
            AdmissionsLastHour = request.AdmissionsLastHour,
            AdmissionReason = request.AdmissionReason?.Trim() ?? "",
            ExpectedSurgeWindow = request.ExpectedSurgeWindow?.Trim() ?? "",
            ShiftSchedule = request.ShiftSchedule?.Trim() ?? "",

            // Use the unique (deduped) list so 1 staff = 1 email = 1 link.
            Recipients = uniqueRecipients,
            NextInviteIndex = 0
        };

        _campaigns[campaign.Id] = campaign;

        // Send initial wave: invite ALL recipients.
        var invites = new List<InviteInfo>();

        while (true)
        {
            var invite = await InviteNextAsync(campaign, baseUrl);
            if (invite == null)
                break;
            invites.Add(invite);
        }

        return new StartSurgeResponse
        {
            CampaignId = campaign.Id,
            RequiredStaff = campaign.RequiredStaff,
            AcceptedStaff = campaign.ConfirmedCount,
            ConfirmedStaff = campaign.ConfirmedCount,
            PendingAcceptedStaff = campaign.PendingAcceptCount,
            InvitationsSent = invites.Count,
            RemainingNeeded = Math.Max(0, campaign.RequiredStaff - campaign.ConfirmedCount),
            Invites = invites
        };
    }

    /// <summary>
    /// Returns a user-friendly status snapshot for Swagger/testing.
    /// </summary>
    public CampaignStatusResponse GetStatus(string campaignId)
    {
        if (!_campaigns.TryGetValue(campaignId, out var campaign))
            throw new KeyNotFoundException("Campaign not found.");

        return new CampaignStatusResponse
        {
            CampaignId = campaign.Id,
            StaffGroup = campaign.StaffGroup,
            Situation = campaign.Situation,
            SurgeRiskLevel = campaign.SurgeRiskLevel,
            RequiredStaff = campaign.RequiredStaff,
            AcceptedStaff = campaign.ConfirmedCount,
            ConfirmedStaff = campaign.ConfirmedCount,
            PendingAcceptedStaff = campaign.PendingAcceptCount,
            RemainingNeeded = Math.Max(0, campaign.RequiredStaff - campaign.ConfirmedCount),
            IsFilled = campaign.IsFilled,
            FinalPremiumPercent = campaign.FinalPremiumPercent,
            FinalizedUtc = campaign.FinalizedUtc,
            Sessions = campaign.Sessions.Values
                .OrderBy(s => s.CreatedUtc)
                .Select(s => new SessionStatusItem
                {
                    LinkCode = s.Code,
                    Recipient = s.Recipient,
                    Status = s.Status.ToString(),
                    DeclineCount = s.DeclineCount,
                    AcceptedPremiumPercent = s.AcceptedPremiumPercent,
                    CreatedUtc = s.CreatedUtc,
                    LastActivityUtc = s.LastActivityUtc
                })
                .ToList()
        };
    }

    /// <summary>
    /// Returns the current session state for the web chat UI (decline count, remaining needed, etc.).
    /// </summary>
    public SessionStateResponse GetSessionState(string code)
    {
        var (campaign, session) = GetSession(code);

        // If the campaign is filled, or this session is already finalized, the UI should be closed.
        var isFinalized = session.Status is SessionStatus.Confirmed or SessionStatus.AcceptedPendingManager or SessionStatus.Declined or SessionStatus.Closed;
        var shouldClose = isFinalized || (campaign.IsFilled && session.Status != SessionStatus.Confirmed);
        var closeReason = shouldClose
            ? (campaign.IsFilled && session.Status != SessionStatus.Confirmed
                ? "Campaign already filled"
                : session.Status switch
                {
                    SessionStatus.Confirmed => "Confirmed",
                    SessionStatus.AcceptedPendingManager => "Pending manager confirmation",
                    SessionStatus.Declined => "Declined",
                    SessionStatus.Closed => "Closed",
                    _ => "Closed"
                })
            : null;

        return new SessionStateResponse
        {
            SessionStatus = shouldClose ? SessionStatus.Closed.ToString() : session.Status.ToString(),
            RemainingNeeded = Math.Max(0, campaign.RequiredStaff - campaign.ConfirmedCount),
            DeclineCount = session.DeclineCount,
            MaxDeclines = MaxDeclines,
            ShouldClose = shouldClose,
            CloseReason = closeReason
        };
    }

    /// <summary>
    /// Marks a session as "engaged" when staff opens the link.
    /// This helps you track activity, but does not change negotiation level.
    /// </summary>
    public void MarkOpened(string code)
    {
        var (campaign, session) = GetSession(code);
        if (campaign.IsFilled && session.Status != SessionStatus.Confirmed)
        {
            session.Status = SessionStatus.Closed;
        }

        if (session.Status == SessionStatus.Offered)
            session.Status = SessionStatus.Engaged;

        session.LastActivityUtc = DateTime.UtcNow;
    }

    /// <summary>
    /// Handles a staff reply in the chat.
    /// This applies rules:
    /// - accept => mark accepted; if campaign filled, close others
    /// - decline => escalate compensation up to 3 levels; then mark declined and invite next staff
    /// - other text => continue conversation without incrementing decline
    /// </summary>
    public async Task<ReplyResponse> HandleReplyAsync(string code, string staffMessage, string baseUrl)
    {
        var (campaign, session) = GetSession(code);

        // If this session is already finalized, keep it closed and respond politely.
        if (session.Status is SessionStatus.Confirmed or SessionStatus.AcceptedPendingManager or SessionStatus.Declined or SessionStatus.Closed)
        {
            await _store.SaveMessageAsync(session.Code, "Staff", staffMessage);

            var finalMsg = session.Status switch
            {
                SessionStatus.Confirmed => "You're confirmed — thank you. You can close this tab.",
                SessionStatus.AcceptedPendingManager => "Your availability has been received and is pending unit manager confirmation. You can close this tab.",
                SessionStatus.Declined => "This invite was declined and is now closed. You can close this tab.",
                _ => "This invite is closed. If coverage is still needed, leadership will send a new invite."
            };

            await _store.SaveMessageAsync(session.Code, "Agent", finalMsg);

            return new ReplyResponse
            {
                AgentMessage = finalMsg,
                SessionStatus = session.Status.ToString(),
                RemainingNeeded = Math.Max(0, campaign.RequiredStaff - campaign.ConfirmedCount),
                DeclineCount = session.DeclineCount,
                MaxDeclines = MaxDeclines,
                ShouldClose = true,
                CloseReason = "Session already finalized"
            };
        }

        // If the campaign is already filled, we close this session politely.
        // We still record the staff message + our response so the chat history looks correct.
        if (campaign.IsFilled && session.Status != SessionStatus.Confirmed)
        {
            session.Status = SessionStatus.Closed;
            session.LastActivityUtc = DateTime.UtcNow;

            await _store.SaveMessageAsync(session.Code, "Staff", staffMessage);

            var filledMsg = "Capacity surge requirement has been filled. Thank you for your time.";
            await _store.SaveMessageAsync(session.Code, "Agent", filledMsg);

            return new ReplyResponse
            {
                AgentMessage = filledMsg,
                SessionStatus = session.Status.ToString(),
                RemainingNeeded = 0,
                DeclineCount = session.DeclineCount,
                MaxDeclines = MaxDeclines,
                ShouldClose = true,
                CloseReason = "Campaign already filled"
            };
        }

        // Record activity.
        session.LastActivityUtc = DateTime.UtcNow;
        if (session.Status == SessionStatus.Offered)
            session.Status = SessionStatus.Engaged;

        // Save the staff message into the conversation store so the web UI can display it.
        await _store.SaveMessageAsync(session.Code, "Staff", staffMessage);

        var normalized = (staffMessage ?? string.Empty).Trim().ToLowerInvariant();
        var isAccept = LooksLikeAccept(normalized);
        var isDecline = LooksLikeDecline(normalized);

	        var isNegotiating = IsNegotiatingOrQuestion(normalized);
	        var isPerksQuestion = IsTransportOrMealQuestion(normalized);

        // If the message is a negotiation/question, do NOT treat it as accept/decline.
        // IMPORTANT: never decrease the authorized offer.
        // - If we're still on Tier 1 (0%), negotiation bumps to Tier 2 (20%).
        // - If we've already escalated (e.g., Tier 3 = 40%), negotiation must stay at that tier.
	        if (isNegotiating)
        {
            // Negotiation/questions should never be treated as an accept/decline.
            // Also, the authorized offer must NEVER move backwards.
            var currentOffer = GetOfferPercentForDeclines(session.DeclineCount);

            // Negotiation implies at least Tier 2 (20%) if we were still at Tier 1 (0%).
            var authorizedOffer = Math.Max(20, currentOffer);

            // If the staff explicitly asks for a higher premium (e.g., "30%" or "beyond 30%"),
            // bump to the next tier if available (20% -> 40%).
            if (TryExtractRequestedPremiumPercent(normalized, out var requested) && requested > authorizedOffer)
            {
                if (authorizedOffer < 40)
                    authorizedOffer = 40;
            }

            // Persist the offer tier so later messages (including more negotiation) do not revert.
            if (authorizedOffer >= 40)
                session.DeclineCount = Math.Max(session.DeclineCount, 2); // Tier 3
            else if (authorizedOffer >= 20)
                session.DeclineCount = Math.Max(session.DeclineCount, 1); // Tier 2


	            var msg = isPerksQuestion
	                ? BuildNoTransportMealOfferMessage(
	                    authorizedOfferPercent: authorizedOffer,
	                    hospitalName: campaign.HospitalName,
	                    unitName: campaign.UnitName,
	                    shiftSchedule: campaign.ShiftSchedule)
	                : BuildAuthorizedOfferConfirmationMessage(
	                    authorizedOfferPercent: authorizedOffer,
	                    hospitalName: campaign.HospitalName,
	                    unitName: campaign.UnitName,
	                    shiftSchedule: campaign.ShiftSchedule);

            await _store.SaveMessageAsync(session.Code, "Agent", msg);

            return new ReplyResponse
            {
                AgentMessage = msg,
                SessionStatus = session.Status.ToString(),
                RemainingNeeded = Math.Max(0, campaign.RequiredStaff - campaign.ConfirmedCount),
                DeclineCount = session.DeclineCount,
                MaxDeclines = MaxDeclines,
                ShouldClose = false
            };
        }


        if (isAccept)
        {
            // Staff accepted.
            // Make this idempotent: if they click/submit "accept" multiple times,
            // it should NOT count multiple times.
            if (session.Status == SessionStatus.AcceptedPendingManager || session.Status == SessionStatus.Confirmed)
            {
                var alreadyMsg = session.Status == SessionStatus.Confirmed
                    ? "You're confirmed — thank you."
                    : "Your availability has been received and is pending unit manager confirmation.";

                await _store.SaveMessageAsync(session.Code, "Agent", alreadyMsg);
                return new ReplyResponse
                {
                    AgentMessage = alreadyMsg,
                    SessionStatus = session.Status.ToString(),
                    RemainingNeeded = Math.Max(0, campaign.RequiredStaff - campaign.ConfirmedCount),
                    DeclineCount = session.DeclineCount,
                    MaxDeclines = MaxDeclines,
                    ShouldClose = true,
                    CloseReason = "Already accepted"
                };
            }

            // If the session was previously closed/declined, don't allow changing it back.
            if (session.Status is SessionStatus.Declined or SessionStatus.Closed)
            {
                var closedMsg = "This invite is closed. If coverage is still needed, leadership will send a new invite.";
                await _store.SaveMessageAsync(session.Code, "Agent", closedMsg);
                return new ReplyResponse
                {
                    AgentMessage = closedMsg,
                    SessionStatus = session.Status.ToString(),
                    RemainingNeeded = Math.Max(0, campaign.RequiredStaff - campaign.ConfirmedCount),
                    DeclineCount = session.DeclineCount,
                    MaxDeclines = MaxDeclines,
                    ShouldClose = true,
                    CloseReason = "Invite closed"
                };
            }

            session.Status = SessionStatus.AcceptedPendingManager;
            session.AcceptedUtc = DateTime.UtcNow;
            session.AcceptedPremiumPercent = GetOfferPercentForDeclines(session.DeclineCount);

            // Send a professional acknowledgement with shift details, then close the UI.
            var agentMsg = BuildAcceptGreeting(
                hospitalName: campaign.HospitalName,
                unitName: campaign.UnitName,
                shiftSchedule: campaign.ShiftSchedule);

            await _store.SaveMessageAsync(session.Code, "Agent", agentMsg);

            return new ReplyResponse
            {
                AgentMessage = agentMsg,
                SessionStatus = session.Status.ToString(),
                RemainingNeeded = Math.Max(0, campaign.RequiredStaff - campaign.ConfirmedCount),
                DeclineCount = session.DeclineCount,
                MaxDeclines = MaxDeclines,
                ShouldClose = true,
                CloseReason = "Pending manager confirmation"
            };
        }

        if (isDecline)
        {
            // Staff declined. Increase decline count.
            session.DeclineCount++;

            // After 3 declines, we stop negotiating with this staff member.
            if (session.DeclineCount >= MaxDeclines)
            {
                session.Status = SessionStatus.Declined;
                // Final polite close-out message before disabling the UI.
                var agentMsg = BuildFinalDeclineGreeting();
                await _store.SaveMessageAsync(session.Code, "Agent", agentMsg);

                return new ReplyResponse
                {
                    AgentMessage = agentMsg,
                    SessionStatus = session.Status.ToString(),
                    RemainingNeeded = Math.Max(0, campaign.RequiredStaff - campaign.ConfirmedCount),
                    DeclineCount = session.DeclineCount,
                    MaxDeclines = MaxDeclines,
                    ShouldClose = true,
                    CloseReason = "Declined"
                };
            }

            // Otherwise, escalate to the next negotiation level and generate the next message.
            var next = await _agent.RunAsync(
                sessionId: session.Code,
                context: new NegotiationContext
                {
                    StaffGroup = campaign.StaffGroup,
                    HospitalName = campaign.HospitalName,
                    UnitName = campaign.UnitName,
                    IncidentDateTime = campaign.IncidentDateTime,
                    AdmissionsLastHour = campaign.AdmissionsLastHour,
                    AdmissionReason = campaign.AdmissionReason,
                    ExpectedSurgeWindow = campaign.ExpectedSurgeWindow,
                    ShiftSchedule = campaign.ShiftSchedule,
                    Situation = campaign.Situation,
                    SurgeRiskLevel = campaign.SurgeRiskLevel,
                    DeclineCount = session.DeclineCount,
                    IsUnderStaffed = !campaign.IsFilled
                },
                staffMessage: null);

            return new ReplyResponse
            {
                AgentMessage = next,
                SessionStatus = session.Status.ToString(),
                RemainingNeeded = Math.Max(0, campaign.RequiredStaff - campaign.ConfirmedCount),
                DeclineCount = session.DeclineCount,
                MaxDeclines = MaxDeclines,
                ShouldClose = false
            };
        }

        // Neutral/other response: continue conversation, but don't count as a decline.
        var reply = await _agent.RunAsync(
            sessionId: session.Code,
            context: new NegotiationContext
            {
                StaffGroup = campaign.StaffGroup,
                    HospitalName = campaign.HospitalName,
                    UnitName = campaign.UnitName,
                    IncidentDateTime = campaign.IncidentDateTime,
                    AdmissionsLastHour = campaign.AdmissionsLastHour,
                    AdmissionReason = campaign.AdmissionReason,
                    ExpectedSurgeWindow = campaign.ExpectedSurgeWindow,
                    ShiftSchedule = campaign.ShiftSchedule,
                Situation = campaign.Situation,
                SurgeRiskLevel = campaign.SurgeRiskLevel,
                DeclineCount = session.DeclineCount,
                IsUnderStaffed = !campaign.IsFilled
            },
            staffMessage: null);

        return new ReplyResponse
        {
            AgentMessage = reply,
            SessionStatus = session.Status.ToString(),
            RemainingNeeded = Math.Max(0, campaign.RequiredStaff - campaign.ConfirmedCount),
            DeclineCount = session.DeclineCount,
            MaxDeclines = MaxDeclines,
            ShouldClose = false
        };
    }

    /// <summary>
    /// Creates and sends the next invite for a campaign.
    /// Returns invite info (recipient + code + link).
    /// </summary>
    private async Task<InviteInfo?> InviteNextAsync(SurgeCampaign campaign, string baseUrl)
    {
        if (campaign.NextInviteIndex >= campaign.Recipients.Count)
            return null;

        var recipient = campaign.Recipients[campaign.NextInviteIndex++];
        var code = GenerateShortCode();

        var session = new StaffSession
        {
            Code = code,
            Recipient = recipient,
            Status = SessionStatus.Offered,
            DeclineCount = 0,
            LastActivityUtc = DateTime.UtcNow
        };

        campaign.Sessions[code] = session;
        _codeToCampaignId[code] = campaign.Id;

        var linkUrl = CombineUrl(baseUrl, $"/n/{code}");

        // IMPORTANT:
        // Do NOT call the AI agent here.
        // If we call the AI with an empty history, it may hallucinate a "Staff:" message
        // (because the prompt expects a last staff line).
        // Instead, we seed the conversation with a clear initial outreach message that asks
        // the staff member to help cover the surge.
        var chatOpener = BuildChatOpener(campaign);
        await _store.SaveMessageAsync(code, "Agent", chatOpener);

        // Build the notification (email body) using the preferred "Dear ICU Team" template.
        var subject = $"Hospital Surge Alert (Risk {campaign.SurgeRiskLevel}/5)";
        var body = await BuildNotificationBodyAsync(campaign, linkUrl);

        // Send notification.
        // - If Gmail SMTP is configured, this sends a real email.
        // - Otherwise it writes into /outbox.
        await _notifier.SendAsync(recipient, subject, body);

        return new InviteInfo
        {
            Recipient = recipient,
            LinkCode = code,
            LinkUrl = linkUrl
        };
    }

    /// <summary>
    /// Helper to find a session and its campaign, given the short link code.
    /// </summary>
    private (SurgeCampaign Campaign, StaffSession Session) GetSession(string code)
    {
        if (!_codeToCampaignId.TryGetValue(code, out var campaignId))
            throw new KeyNotFoundException("Unknown link code.");

        if (!_campaigns.TryGetValue(campaignId, out var campaign))
            throw new KeyNotFoundException("Campaign not found.");

        if (!campaign.Sessions.TryGetValue(code, out var session))
            throw new KeyNotFoundException("Session not found.");

        return (campaign, session);
    }

    /// <summary>
    /// Validates the StartSurge request to keep the API simple and predictable.
    /// </summary>
    private static void ValidateStartRequest(StartSurgeRequest request)
    {
        if (request.RequiredStaff <= 0)
            throw new ArgumentException("RequiredStaff must be >= 1.");

        if (request.SurgeRiskLevel < 1 || request.SurgeRiskLevel > 5)
            throw new ArgumentException("SurgeRiskLevel must be between 1 and 5.");

        if (request.EmailAddresses == null || request.EmailAddresses.Count == 0)
            throw new ArgumentException("EmailAddresses must contain at least one address.");

        if (string.IsNullOrWhiteSpace(request.StaffGroup))
            throw new ArgumentException("StaffGroup is required.");

        if (string.IsNullOrWhiteSpace(request.Situation))
            throw new ArgumentException("Situation is required.");
    }

    /// <summary>
    /// Builds the notification body the staff will receive (email body in this demo).
    /// Includes the short chat link.
    /// </summary>
    private async Task<string> BuildNotificationBodyAsync(SurgeCampaign campaign, string linkUrl)
    {
        var staffGroup = string.IsNullOrWhiteSpace(campaign.StaffGroup) ? "Staff" : campaign.StaffGroup.Trim();
        var hospital = string.IsNullOrWhiteSpace(campaign.HospitalName) ? "the hospital" : campaign.HospitalName.Trim();
        var unit = string.IsNullOrWhiteSpace(campaign.UnitName) ? "the unit" : campaign.UnitName.Trim();
        var inc = campaign.IncidentDateTime ?? DateTimeOffset.Now;
        var timeSinceText = BuildTimeSinceText(inc);
        var reason = string.IsNullOrWhiteSpace(campaign.AdmissionReason) ? campaign.Situation : campaign.AdmissionReason.Trim();
        var window = string.IsNullOrWhiteSpace(campaign.ExpectedSurgeWindow) ? "the next few hours" : campaign.ExpectedSurgeWindow.Trim();
        var shift = string.IsNullOrWhiteSpace(campaign.ShiftSchedule) ? "the next available shift" : campaign.ShiftSchedule.Trim();

        // Generate the clinical briefing paragraph using the LLM, with a safe deterministic fallback.
        var briefing = await _ai.GenerateClinicalBriefingAsync(
            incidentDateTime: inc,
            timeSinceText: timeSinceText,
            admissionsLastHour: campaign.AdmissionsLastHour,
            hospitalName: hospital,
            admissionReason: reason,
            unitName: unit,
            expectedSurgeWindow: window);

        return $@"Dear {staffGroup} Team,

{briefing}

Can we count on you to come in for work {shift} at the {unit}?

Please respond using your unique link (availability is pending unit manager confirmation):
{linkUrl}

Thank you,
Hospital Staffing Coordinator
";
    }

    private static string BuildTimeSinceText(DateTimeOffset incidentDateTime)
    {
        var hoursSince = Math.Max(0.0, (DateTimeOffset.Now - incidentDateTime).TotalHours);
        if (hoursSince < 1.0)
            return "Within the last hour";

        var wholeHours = (int)Math.Floor(hoursSince);
        return wholeHours == 1 ? "Within the last 1 hour" : $"Within the last {wholeHours} hours";
    }

    /// <summary>
    /// Seeds the web chat with an initial outreach message.
    /// 
    /// Why this exists:
    /// - When a session is brand-new, there is no "Staff:" message yet.
    /// - Calling the AI with an empty history can cause it to hallucinate a staff message.
    /// 
    /// So we create the first message deterministically:
    /// - clearly asks the staff member to help cover the surge
    /// - tells them what to reply
    /// </summary>
    private static string BuildChatOpener(SurgeCampaign campaign)
    {
        var hospital = string.IsNullOrWhiteSpace(campaign.HospitalName) ? "the hospital" : campaign.HospitalName.Trim();
        var unit = string.IsNullOrWhiteSpace(campaign.UnitName) ? "the unit" : campaign.UnitName.Trim();

        var admissionsTxt = campaign.AdmissionsLastHour.HasValue ? campaign.AdmissionsLastHour.Value.ToString() : "several";
        var reason = string.IsNullOrWhiteSpace(campaign.AdmissionReason) ? campaign.Situation : campaign.AdmissionReason.Trim();
        var window = string.IsNullOrWhiteSpace(campaign.ExpectedSurgeWindow) ? "the next few hours" : campaign.ExpectedSurgeWindow.Trim();
        var shift = string.IsNullOrWhiteSpace(campaign.ShiftSchedule) ? "the next available shift" : campaign.ShiftSchedule.Trim();

        // Only include incident time / "Within the last ..." when an incident timestamp was provided.
        var incidentPrefix = "";
        if (campaign.IncidentDateTime.HasValue)
        {
            var inc = campaign.IncidentDateTime.Value;
            var timeSinceText = BuildTimeSinceText(inc);
            incidentPrefix = $"{inc:yyyy-MM-dd HH:mm zzz} {timeSinceText}, ";
        }

        return $"{incidentPrefix}{admissionsTxt} people have been admitted to the {hospital} Emergency Department due to {reason}. " +
               $"We’re expecting a surge at the {unit} within {window}. Current capacity may be exceeded, creating a risk of delayed critical care and preventable patient harm. " +
               $"Can we count on you to come in for work {shift} at the {unit}? " +
               "Reply ACCEPT if you’re available (pending unit manager confirmation), or DECLINE if you can’t.";
    }

    private static bool IsNegotiatingOrQuestion(string msg)
    {
        if (string.IsNullOrWhiteSpace(msg))
            return false;

        // Question mark is a strong signal.
        if (msg.Contains("?"))
            return true;

        // Common negotiation / clarification cues.
        string[] cues =
        {
            "incentive", "premium", "crisis pay", "hazard", "ot", "overtime", "differential", "differentials",
            "rate", "higher", "increase", "increased", "beyond", "additional", "confirm whether", "can you confirm",
            "before confirming", "may we discuss", "discuss", "negotiate"
        };

        return cues.Any(c => msg.Contains(c));
    }

    bool TryExtractRequestedPremiumPercent(string msg, out int requestedPercent)
    {
        requestedPercent = 0;
        if (string.IsNullOrWhiteSpace(msg))
            return false;

        // Look for patterns like "30%", "30 %", "30 percent", "30pct".
        var matches = System.Text.RegularExpressions.Regex.Matches(
            msg,
            @"(?<!\d)(\d{1,3})\s*(%|percent|pct)\b",
            System.Text.RegularExpressions.RegexOptions.IgnoreCase);

        int max = 0;
        foreach (System.Text.RegularExpressions.Match m in matches)
        {
            if (int.TryParse(m.Groups[1].Value, out var n))
                max = Math.Max(max, n);
        }

        if (max > 0)
        {
            requestedPercent = max;
            return true;
        }

        // Handle "how about 30" when followed by negotiation words (premium/rate/incentive).
        var m2 = System.Text.RegularExpressions.Regex.Match(
            msg,
            @"\bhow about\s+(\d{1,3})\b",
            System.Text.RegularExpressions.RegexOptions.IgnoreCase);
        if (m2.Success && int.TryParse(m2.Groups[1].Value, out var n2))
        {
            if (msg.Contains("premium") || msg.Contains("rate") || msg.Contains("incentive"))
            {
                requestedPercent = n2;
                return true;
            }
        }

        return false;
    }


    private static string BuildAuthorizedOfferConfirmationMessage(int authorizedOfferPercent, string hospitalName, string unitName, string shiftSchedule)
    {
        var hospital = string.IsNullOrWhiteSpace(hospitalName) ? "the hospital" : hospitalName.Trim();
        var unit = string.IsNullOrWhiteSpace(unitName) ? "the unit" : unitName.Trim();
        var shift = string.IsNullOrWhiteSpace(shiftSchedule) ? "the scheduled shift" : shiftSchedule.Trim();

        // Safety: only allow 20% or 40% in negotiation confirmation messaging.
        // Tier 1 (0%) is the initial outreach and should not be used as a negotiation confirmation response.
        var offer = authorizedOfferPercent >= 40 ? 40 : 20;

        string[] variants =
        {
            $"Thank you for your response. We’re offering a premium of {offer}% on top of your hourly rate. Can we secure your commitment to come to work {shift} at the {unit}, {hospital}? Please reply ACCEPT to confirm.",
            $"Understood — thank you. The current authorized offer is a {offer}% premium on top of your hourly rate. Please confirm if you accept coverage {shift} at the {unit}, {hospital} by replying ACCEPT.",
            $"Thank you. We can approve a {offer}% premium on top of your hourly rate for this surge shift. Please reply ACCEPT if you confirm you can work {shift} at the {unit}, {hospital}.",
            $"Thanks for checking. The premium available for this request is {offer}% on top of your hourly rate. If you’re able to commit to {shift} at the {unit}, {hospital}, please reply ACCEPT to confirm."
        };

        return variants[Random.Shared.Next(variants.Length)];
    }

	private static bool IsTransportOrMealQuestion(string msg)
	{
	    if (string.IsNullOrWhiteSpace(msg)) return false;
	    // Staff asking for perks outside the authorized policy.
	    return msg.Contains("transport")
	        || msg.Contains("transportation")
	        || msg.Contains("shuttle")
	        || msg.Contains("meal")
	        || msg.Contains("voucher")
	        || msg.Contains("food")
	        || msg.Contains("allowance");
	}

	private static string BuildNoTransportMealOfferMessage(int authorizedOfferPercent, string hospitalName, string unitName, string shiftSchedule)
	{
	    var hospital = string.IsNullOrWhiteSpace(hospitalName) ? "the hospital" : hospitalName.Trim();
	    var unit = string.IsNullOrWhiteSpace(unitName) ? "the unit" : unitName.Trim();
	    var shift = string.IsNullOrWhiteSpace(shiftSchedule) ? "the scheduled shift" : shiftSchedule.Trim();

	    // Safety: only allow 20% or 40% in negotiation confirmation messaging.
	    var offer = authorizedOfferPercent >= 40 ? 40 : 20;

	    string[] variants =
	    {
	        $"Sorry, we don’t have shuttle service or meal vouchers available for this request. We can offer a premium of {offer}% on top of your hourly rate. Please reply ACCEPT if you confirm you can work {shift} at the {unit}, {hospital}.",
	        $"Thank you for asking. Transportation and meal vouchers aren’t available for this surge request. The authorized premium is {offer}% on top of your hourly rate. Please reply ACCEPT to confirm {shift} at the {unit}, {hospital}.",
	        $"Understood. We don’t have transport or meal support available for this assignment. We can offer a {offer}% premium on top of your hourly rate. Please reply ACCEPT if you can commit to {shift} at the {unit}, {hospital}.",
	        $"Thanks for checking. Shuttle service and meal vouchers are not included in this request. The approved premium is {offer}% on top of your hourly rate. Reply ACCEPT to confirm {shift} at the {unit}, {hospital}."
	    };

	    return variants[Random.Shared.Next(variants.Length)];
	}

static bool LooksLikeAccept(string msg)
        => msg.Contains("accept") || msg == "yes" || msg.StartsWith("yes ") || msg.Contains("i can") || msg.Contains("available") || msg.Contains("ok");

    private static bool LooksLikeDecline(string msg)
        => msg.Contains("decline") || msg.Contains("can't") || msg.Contains("cant") || msg.Contains("no") || msg.Contains("not available") || msg.Contains("sorry");

    private static string BuildAcceptGreeting(string hospitalName, string unitName, string shiftSchedule)
    {
        var hospital = string.IsNullOrWhiteSpace(hospitalName) ? "the hospital" : hospitalName.Trim();
        var unit = string.IsNullOrWhiteSpace(unitName) ? "the unit" : unitName.Trim();
        var shift = string.IsNullOrWhiteSpace(shiftSchedule) ? "the scheduled shift" : shiftSchedule.Trim();

        // Same intent, slightly varied wording.
        var options = new[]
        {
            $"Great! The shift needing to be filled is {shift} at the {unit} of {hospital}. Once confirmed, we will notify you. Thank you for your service!",
            $"Thank you. Coverage is needed {shift} at the {unit}, {hospital}. Your response is pending unit manager confirmation; we will notify you once finalized. Thank you for your service!",
            $"Thank you for stepping in. The shift is {shift} at the {unit} of {hospital}. We’ll follow up once the unit manager confirms coverage. Thank you for your service!",
            $"Confirmed receipt — thank you. The requested shift is {shift} at the {unit}, {hospital}. We’ll notify you as soon as confirmation is completed. Thank you for your service!"
        };

        return options[Random.Shared.Next(options.Length)];
    }

    private static string BuildFinalDeclineGreeting()
    {
        var options = new[]
        {
            "Thank you for your time. Unfortunately, we’re unable to meet your request at this time. We appreciate your support and service.",
            "Thank you for your response. Unfortunately, we’re unable to proceed further at this time. We appreciate your time and service.",
            "Thank you for letting us know. We’re unable to move forward with this request at this time. We appreciate your support and service.",
            "Thank you for your time. We’re unable to accommodate the request at the moment. We appreciate your support and service."
        };

        return options[Random.Shared.Next(options.Length)];
    }

    
    private static int GetOfferPercentForDeclines(int declineCount)
    {
        // declineCount: 0 => level 1, 1 => level 2, 2+ => level 3 (capped)
        return declineCount switch
        {
            <= 0 => 0,
            1 => 20,
            _ => 40
        };
    }

    private const string CapacityFilledMessage = "Capacity surge requirement has been filled. Thank you for your time.";

    /// <summary>
    /// Unit manager confirms/schedules a set of accepting staff.
    /// When the required confirmations are reached, the campaign is finalized:
    /// - all confirmed staff get the same final premium (highest among confirmed)
    /// - everyone else (declined / no-reply / not-selected) gets the capacity-filled notice
    /// </summary>
    public async Task<CampaignStatusResponse> ManagerConfirmAsync(string campaignId, IEnumerable<string> codesToConfirm)
    {
        if (!_campaigns.TryGetValue(campaignId, out var campaign))
            throw new KeyNotFoundException("Campaign not found.");

        var codeSet = new HashSet<string>(codesToConfirm.Where(c => !string.IsNullOrWhiteSpace(c)).Select(c => c.Trim()));
        if (codeSet.Count == 0)
            throw new ArgumentException("No codes provided.");

        // Confirm only sessions that accepted and are pending.
        foreach (var code in codeSet)
        {
            if (!campaign.Sessions.TryGetValue(code, out var session))
                continue;

            if (session.Status != SessionStatus.AcceptedPendingManager)
                continue;

            session.Status = SessionStatus.Confirmed;
            session.ConfirmedUtc = DateTime.UtcNow;
            session.LastActivityUtc = DateTime.UtcNow;
        }

        // If we have enough confirmed, finalize and send notifications.
        if (campaign.IsFilled && campaign.FinalizedUtc is null)
        {
            await FinalizeCampaignAsync(campaign);
        }

        return GetStatus(campaignId);
    }

    /// <summary>List sessions that are awaiting manager confirmation.</summary>
    public List<SessionStatusItem> GetPendingAccepts(string campaignId)
    {
        if (!_campaigns.TryGetValue(campaignId, out var campaign))
            throw new KeyNotFoundException("Campaign not found.");

        return campaign.Sessions.Values
            .Where(s => s.Status == SessionStatus.AcceptedPendingManager)
            .OrderByDescending(s => s.AcceptedUtc ?? DateTime.MinValue)
            .Select(s => new SessionStatusItem
            {
                LinkCode = s.Code,
                Recipient = s.Recipient,
                Status = s.Status.ToString(),
                DeclineCount = s.DeclineCount,
                AcceptedPremiumPercent = s.AcceptedPremiumPercent,
                CreatedUtc = s.CreatedUtc,
                LastActivityUtc = s.LastActivityUtc
            })
            .ToList();
    }

    private async Task FinalizeCampaignAsync(SurgeCampaign campaign)
    {
        // Determine final premium: highest among CONFIRMED staff.
        var finalPremium = campaign.Sessions.Values
            .Where(s => s.Status == SessionStatus.Confirmed)
            .Select(s => s.AcceptedPremiumPercent ?? 0)
            .DefaultIfEmpty(0)
            .Max();

        campaign.FinalPremiumPercent = finalPremium;
        campaign.FinalizedUtc = DateTime.UtcNow;

        // 1) Notify confirmed staff (same premium for all).
        foreach (var s in campaign.Sessions.Values.Where(s => s.Status == SessionStatus.Confirmed))
        {
            var msg =
                $"Your decking in the {campaign.UnitName} has been confirmed for {campaign.ShiftSchedule}. " +
                $"The final premium to be added to your hourly rate is {finalPremium}%. Thank you for your service!";

            await _store.SaveMessageAsync(s.Code, "Agent", msg);
            await _notifier.SendAsync(s.Recipient, "Shift Confirmed", msg);
        }

        // 2) Notify everyone else (declined / no reply / not selected).
        foreach (var s in campaign.Sessions.Values.Where(s => s.Status != SessionStatus.Confirmed))
        {
            // Close any remaining open / pending sessions.
            if (s.Status is SessionStatus.Offered or SessionStatus.Engaged or SessionStatus.AcceptedPendingManager)
                s.Status = SessionStatus.Closed;

            await _store.SaveMessageAsync(s.Code, "Agent", CapacityFilledMessage);
            await _notifier.SendAsync(s.Recipient, "Surge Coverage Filled", CapacityFilledMessage);
        }
    }


    /// <summary>
    /// When campaign is filled, we close all other sessions so they stop negotiating.
    /// </summary>
    private static void CloseOtherSessions(SurgeCampaign campaign, string exceptCode)
    {
        foreach (var s in campaign.Sessions.Values)
        {
            if (s.Code == exceptCode) continue;
            if (s.Status == SessionStatus.Confirmed) continue;
            s.Status = SessionStatus.Closed;
        }
    }

    /// <summary>
    /// Generates a short URL-friendly code.
    /// </summary>
    private static string GenerateShortCode()
    {
        // 8 chars is easy to type, still very unlikely to collide.
        const string alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        Span<char> chars = stackalloc char[8];
        var rnd = Random.Shared;
        for (var i = 0; i < chars.Length; i++)
            chars[i] = alphabet[rnd.Next(alphabet.Length)];
        return new string(chars);
    }

    private static string CombineUrl(string baseUrl, string path)
    {
        if (string.IsNullOrWhiteSpace(baseUrl)) return path;
        if (baseUrl.EndsWith('/')) baseUrl = baseUrl.TrimEnd('/');
        return baseUrl + path;
    }
}