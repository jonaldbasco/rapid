﻿using HospitalSurgeAgent.Core.Agents;
using HospitalSurgeAgent.Core.Models;
using HospitalSurgeAgent.Core.Services;


var apiKey = Environment.GetEnvironmentVariable("OPENAI_API_KEY");
Console.WriteLine($"KEY LENGTH: {apiKey?.Length}");

if (string.IsNullOrEmpty(apiKey))
{
    throw new Exception("OPENAI_API_KEY is not set!");
}
var ai = new OpenAIService(apiKey);
var agent = new SurgeNegotiationAgent(ai);

var sessionId = Guid.NewGuid().ToString();

var context = new NegotiationContext
{
    StaffGroup = "ICU Nurses",
    DeclineCount = 2,
    SurgeRiskLevel = 4,
    Situation = "Example test: Emergency department surge; need additional ICU coverage tonight.",
    IsUnderStaffed = true
};

var message = await agent.RunAsync(sessionId, context, staffMessage: null);

Console.WriteLine("=== Negotiation Message ===");
Console.WriteLine(message);
Console.WriteLine(
    Environment.GetEnvironmentVariable("OPENAI_API_KEY") != null
        ? "API key loaded"
        : "API key NOT found"
);
