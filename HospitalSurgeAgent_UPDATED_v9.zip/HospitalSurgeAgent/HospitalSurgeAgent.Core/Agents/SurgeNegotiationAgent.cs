﻿using HospitalSurgeAgent.Core.Models;
using HospitalSurgeAgent.Core.Rules;
using HospitalSurgeAgent.Core.Services;
using HospitalSurgeAgent.Core.Abstractions;

namespace HospitalSurgeAgent.Core.Agents;

public class SurgeNegotiationAgent
{
    private readonly NegotiationRulesEngine _rules;
    private readonly OpenAIService _ai;
    private readonly IConversationStore? _store; // ✅ nullable

    // ✅ Store is OPTIONAL now
    public SurgeNegotiationAgent(
        OpenAIService ai,
        IConversationStore? store = null)
    {
        _rules = new NegotiationRulesEngine();
        _ai = ai;
        _store = store;
    }

    /// <summary>
    /// Runs one "turn" of the negotiation.
    /// 
    /// Inputs:
    /// - sessionId: unique negotiation session id (we use the short link code)
    /// - context: describes the situation and the current decline count
    /// - staffMessage: optional new message from the staff member (reply)
    /// 
    /// Output:
    /// - the next agent message to send/display
    /// </summary>
    public async Task<string> RunAsync(
        string sessionId,
        NegotiationContext context,
        string? staffMessage = null)
    {
        string transcript = "";

        // ✅ Only use memory IF store exists
        if (_store != null)
        {
            // Save staff message
            if (!string.IsNullOrWhiteSpace(staffMessage))
            {
                await _store.SaveMessageAsync(
                    sessionId,
                    "Staff",
                    staffMessage);
            }

            var history = await _store.GetConversationAsync(sessionId);

            transcript = string.Join("\n",
                history.Select(m => $"{m.Sender}: {m.Message}"));
        }

        // Apply rules
        var level = _rules.GetLevel(context.DeclineCount);

        var reply = await _ai.GenerateNegotiationMessage(
            staffGroup: context.StaffGroup,
            incentive: level.IncentiveIncreasePercent,
            tone: level.Tone,
            situation: context.Situation,
            surgeRiskLevel: context.SurgeRiskLevel,
            history: transcript,
            hospitalName: context.HospitalName,
            unitName: context.UnitName,
            incidentDateTime: context.IncidentDateTime,
            admissionsLastHour: context.AdmissionsLastHour,
            admissionReason: context.AdmissionReason,
            expectedSurgeWindow: context.ExpectedSurgeWindow,
            shiftSchedule: context.ShiftSchedule);

        // Save reply if memory enabled
        if (_store != null)
        {
            await _store.SaveMessageAsync(
                sessionId,
                "Agent",
                reply);
        }

        return reply;
    }
}
